<?php
namespace CustomVendor\NewModule\Block;
class Show extends \Magento\Framework\View\Element\Template
{
    public function __construct(\Magento\Framework\View\Element\Template\Context $context)
    {
        parent::__construct($context);
    }
    public function showContent()
    {
        echo"<h1>Module 2 block 1</h1>";
        return __();
    }



}

