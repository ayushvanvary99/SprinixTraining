<?php
namespace CustomVendor\CustomModule\Controller\Block;
class Display extends \Magento\Framework\View\Element\Template
{
public function __construct(\Magento\Framework\View\Element\Template\Context $context)
{
parent::__construct($context);
}
public function sayWelcome(){
    echo"<h1>Moudle 1 block 1</h1>";
    return __();
}



}

