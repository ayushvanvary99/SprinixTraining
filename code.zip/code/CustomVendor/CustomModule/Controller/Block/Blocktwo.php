<?php
namespace CustomVendor\CustomModule\Controller\Block;
class Blocktwo extends \Magento\Framework\View\Element\Template
{
    public function __construct(\Magento\Framework\View\Element\Template\Context $context)
    {
        parent::__construct($context);
    }
    public function doWelcome()
    {
        echo'
<br>
<h2> Pharum in Magento </h2>
<form>
  <label for="fname">First name:</label><br>
  <input type="text" id="fname" name="fname">
   <br>
  <label for="lname">Last name:</label><br>

  <input type="text" id="lname" name="lname" >
  <h4>Choose Language</h4>
  <ul style="list-style-type:none;">
            <li><input type="checkbox"
                       name="language"
                       value="hindi" />
                  Hindi
              </li>
            <li><input type="checkbox"
                       name="language"
                       value="english" />
                  English
              </li>
            <li><input type="checkbox"
                       name="language"
                       value="sanskrite" />
                  Sanskrit
              </li>
        </ul>
        <h4>Gender</h4>
           <label>Male<input type="radio"
                          name="gender"
                          value="male" />
          </label>
        <label>Female<input type="radio"
                            name="gender"
                            value="female" />
</form>';
        return __();
    }



}

