<?php
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\
    ComponentRegistrar::MODULE,
    'CustomVendor_NewModule',
    __DIR__
);
